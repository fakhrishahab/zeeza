-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2016 at 10:11 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zeeza_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`) VALUES
(1, 'head menu'),
(2, 'contact menu'),
(3, 'brand menu'),
(4, 'footer menu');

-- --------------------------------------------------------

--
-- Table structure for table `menu_content`
--

CREATE TABLE IF NOT EXISTS `menu_content` (
  `id` int(11) NOT NULL,
  `menu` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_content`
--

INSERT INTO `menu_content` (`id`, `menu`, `name`, `content`) VALUES
(1, 1, 'Cara Pemesanan', 'Ini Cara Pemesanan'),
(2, 1, 'Daftar Reseller', 'Ini Daftar Reseller'),
(3, 1, 'Sahabat Zeeza', 'Sahabat Zeeza'),
(4, 1, 'FAQ', 'ini FAQ'),
(5, 2, 'whatsapp', '0856 2464 7038'),
(6, 2, 'bbm', '0123jasd'),
(7, 2, 'line', 'zeeza_butik'),
(8, 2, 'instagram', '#ZeezaButik');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `category` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `description` text,
  `price` int(10) DEFAULT NULL,
  `price_disc` int(10) DEFAULT NULL,
  `price_reseller` int(10) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `brand` int(11) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`category`, `type`, `age`, `name`, `description`, `price`, `price_disc`, `price_reseller`, `created_date`, `brand`, `code`, `id`) VALUES
(4, 18, 1, 'Jumber Bayi Aneka Warna', 'Tersedia aneka warna dan ukuran\r\nBahan : Katun ( bebas keringat )\r\nDijual Satuan, untuk harga grosir silahkan hubungi kami', 40000, 37000, 0, '2016-02-14 20:13:40', 1, 'ci004', 1),
(1, 1, 3, 'test', 'test', 11, 22, 33, '2016-02-11 17:00:38', 1, 'ci001', 8),
(2, 5, 3, 'Ini dia', 'Baru jereenn', 123, 456, 789, '2016-02-11 17:09:57', 1, 'ci002', 9),
(2, 4, 1, 'Oshkos New Item', 'Baju Bgus', 100000, 85000, 0, '2016-02-12 06:08:08', 2, 'os001', 10),
(1, 1, 1, 'Circo Baju', 'test', 1000, 2000, 40, '2016-02-12 06:16:12', 1, 'ci003', 11),
(1, 3, 3, 'baju cherokee', 'test', 222, 333, 444, '2016-02-12 06:16:35', 3, 'ch001', 12),
(4, 14, 3, 'Jumper boongan', 'asdasd', 111, 222, 333, '2016-02-12 06:16:57', 4, 'ca001', 13),
(3, 8, 3, 'asdasd', 'asdasd', 1, 2, 3, '2016-02-15 08:09:37', 4, 'ca002', 14),
(3, 11, 3, 'asdas', 'asdasd', 2, 3, 4, '2016-02-15 08:11:28', 3, 'ch002', 15),
(2, 5, 3, 'asdasd', 'asdasd', 222, 33, 444, '2016-02-12 06:17:54', 2, 'os002', 16),
(2, 4, 1, 'asdas', 'asdas', 0, 231, 33, '2016-02-12 06:18:07', 3, 'ch003', 17),
(2, 5, 1, 'asdasd', 'asdasd', 3, 4, 5, '2016-02-15 08:11:37', 3, 'ch004', 18),
(4, 13, 2, 'Kemeja Anak', 'Bahan : Katun Combat', 125000, 110000, 0, '2016-02-14 20:17:56', 4, 'ca003', 19),
(3, 6, 1, 'Atasan Anak Cewek', 'Bahan : Puring & Katun', 65000, 50000, 0, '2016-02-14 20:19:41', 4, 'ca004', 20),
(4, 18, 2, 'Celana Jeans', 'Bahan : Jeans Lembut\r\nMenggunakan karet kualitas tinggi', 85000, 80000, 0, '2016-02-14 20:21:09', 2, 'os003', 21);

-- --------------------------------------------------------

--
-- Table structure for table `product_age`
--

CREATE TABLE IF NOT EXISTS `product_age` (
  `id_age` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_age`
--

INSERT INTO `product_age` (`id_age`, `name`) VALUES
(1, '0 - 1 Tahun'),
(2, '1 - 3 Tahun'),
(3, '3 - 5 Tahun'),
(4, '> 5 Tahun');

-- --------------------------------------------------------

--
-- Table structure for table `product_brand`
--

CREATE TABLE IF NOT EXISTS `product_brand` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `code` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_brand`
--

INSERT INTO `product_brand` (`id`, `name`, `code`) VALUES
(1, 'circo', 'ci'),
(2, 'oshkosh', 'os'),
(3, 'cherokee', 'ch'),
(4, 'carter', 'ca');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE IF NOT EXISTS `product_category` (
  `id_category` int(11) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id_category`, `rank`, `name`) VALUES
(1, 1, 'baby girl'),
(2, 2, 'baby boy'),
(3, 3, 'girl''s room'),
(4, 4, 'boy''s room'),
(5, 5, 'accesories');

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE IF NOT EXISTS `product_type` (
  `id_type` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`id_type`, `id_category`, `rank`, `name`) VALUES
(1, 1, 0, 'headband'),
(2, 1, 1, 'baju'),
(3, 1, 2, 'prewalker'),
(4, 2, 0, 'Baju'),
(5, 2, 1, 'Prewalker'),
(6, 3, 0, 'Atasan'),
(7, 3, 1, 'Rok & Celana'),
(8, 3, 2, 'Jaket & Rompi'),
(9, 3, 3, 'Piyama'),
(10, 3, 4, 'Dress'),
(11, 3, 5, 'Baju Muslim'),
(12, 3, 6, 'Aksesoris'),
(13, 4, 0, 'Kemeja'),
(14, 4, 1, 'Polo Shirt'),
(15, 4, 2, 'Jaket & Rompi'),
(16, 4, 3, 'Baju'),
(17, 4, 4, 'Piyama'),
(18, 4, 5, 'Celana'),
(19, 4, 6, 'Aksesoris');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_content`
--
ALTER TABLE `menu_content`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_age`
--
ALTER TABLE `product_age`
 ADD PRIMARY KEY (`id_age`);

--
-- Indexes for table `product_brand`
--
ALTER TABLE `product_brand`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
 ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `product_type`
--
ALTER TABLE `product_type`
 ADD PRIMARY KEY (`id_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
